package com.ssafy.book;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class BookManagerImpl3 implements IBookManager {
	
	private static final int MAX_SIZE = 100;
	private List<Book> books = new ArrayList<Book>(); //배열객체 생성 
	
	private static IBookManager instance ;  //= new BookManagerImpl1()

	ObjectInputStream ois;
	FileInputStream fis;
	ObjectOutputStream oos;
	FileOutputStream fos;
	
	File file;
	
	public BookManagerImpl3() {
		file = new File("book.dat");
		if(file.exists()) {
			loadData();
		}
		else{
			try {
//				boolean result = file.createNewFile();
				boolean result = file.createNewFile();
				System.out.println("File이 존재 합니까? "+result);
				boolean result2 = file.exists();
				System.out.println(result2+ "없습니다");
			}catch(IOException e) {
				e.printStackTrace();
			} 
		    }
	
	}
	
	@Override
	public void loadData() {
		try {
			ois = new ObjectInputStream(new FileInputStream("file"));
			books = (ArrayList<Book>) ois.readObject();
		}catch(Exception e) {
			
		}finally {
			try {
				
				if(ois!=null) {
				ois.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	@Override
	public void saveData() {
		try {
			oos = new ObjectOutputStream(new FileOutputStream(file));
			oos.writeObject(books);
		}catch(IOException e) {
			
		}finally {
			try {
				if(oos!=null) {
					oos.close();
				}
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
	public synchronized static IBookManager getInstance() {
		if (instance == null){
			instance = new BookManagerImpl3();
		}
		return instance;
	}

		
	
	public void add(Book book) {
		if(searchByIsbn(book.getIsbn())==null) {
			books.add(book);
		}
	}
	@Override
	public void remove(String isbn) {
		for (int i=0 , size=books.size();i<size; ++i) {
			if(books.get(i).getIsbn().equals(isbn)) {
				books.remove(i);
				break;
				
			}
		}
	
	}
	@Override
	public Book[] getList() {
//		Book[] result = new Book[books.size()];   // 원래는 이런식으로 씀 컬렉션에서는 배열로 컨버팅하는데 관련이있구나
//		books.toArray(result);
//		return result;
		
		return books.toArray(new Book[books.size()]);
	}
	
	@Override
	public Book searchByIsbn(String isbn) {
		for (Book book: books) {
			if(book.getIsbn().equals(isbn)) {
				return book;
			}
		}
		return null; // 컴파일을 못할땐 반환 리턴타입이 book인데 찾으면 books[i]써주고 못찾으면 null써준당 
	}
	@Override
	public Book[] searchByTitle(String title) {
		//결과에 해당하는 책의 수를 카운트 
		ArrayList<Book> list= new ArrayList<Book>();
		int index = 0;
		for (Book book:books) {
			if(book.getTitle().contains(title)) {
				list.add(book);
			}
		}
		return list.toArray(new Book[list.size()]);
		}
	
@Override
	public Book[] getBooks() {
	ArrayList<Book> list= new ArrayList<Book>();
	for (Book book:books) {
		if(book instanceof Magazine) {
				continue;
		}
		list.add(book);  // 메거진아닌놈만 추가함 
	}
	return list.toArray(new Book[list.size()]);
	}
	
	@Override
	public Book[] getMagazines() {
		ArrayList<Book> list= new ArrayList<Book>();
		for (Book book:books) {
			if(book instanceof Magazine) {
				list.add(book);
			}
			  // 메거진아닌놈만 추가함 
		}
		return list.toArray(new Book[list.size()]);
		}
	@Override
	public int getTotalPrice() {
		int totalPrice = 0;
		for (Book book:books) {
			totalPrice += book.getPrice();
		}
		return totalPrice;
	}
	@Override
	public double getPriceAvg() {
		return (double)getTotalPrice()/books.size();
	}
//	public void sell(String isbn, int quantity ) {
//			int cnt=0;
//			String to ;
//			for (int i = 0; i < size; i++) {
//				if (books[i] instanceof Book) {
//					
//					cnt += books[i].getQuantity();
//				}
//			to = Integer.toString(cnt);
//
//			
////			public void deletePnum(String num) { // 상품번호로 상품을 삭제
//			int n = 0, size = 0;
//			while (books[n] != null) {
//			if (books[n].getQuantity().compareTo(to) == 0) {
//			size = n;
//						
//			}
//			n++;
//			}
//				books[size] = books[n - 1];
//				books[n - 1] = null;
//		}
//	}
	
	
	public void sell(String isbn ,int quantity) throws ISBNNotFoundException,  QuantityException{ // 상품번호로 상품을 삭제
		Book book = searchByIsbn(isbn);
		if(book==null) throw new ISBNNotFoundException(isbn);
		
		if(book.getQuantity()<quantity) throw new QuantityException(isbn);
		
		book.setQuantity(book.getQuantity()-quantity);
	}
	
	
	public void buy(String isbn, int quantity) throws ISBNNotFoundException{
//		
		Book book = searchByIsbn(isbn);
		if(book==null) throw new ISBNNotFoundException(isbn);
		
		
		book.setQuantity(book.getQuantity()+quantity);
	}
		//		while (books[n] != null) {
//			if (books[n].getQuantity()<num2) break;
//			if (books[n].getIsbn().compareTo(num) == 0) {
//				index = n;
//				
//			}
//			n++;
//		}
//		books[index] = books[n - 1];
//		books[n - 1] = null;
//	}
}


