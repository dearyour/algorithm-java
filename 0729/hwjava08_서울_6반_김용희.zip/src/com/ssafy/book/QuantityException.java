package com.ssafy.book;

public class QuantityException extends Exception{

	public QuantityException(String message) {
		super("수량이 부족합니다.");
	}
}
