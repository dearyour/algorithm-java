package com.ssafy.book;

public class ISBNNotFoundException extends Exception {

		public ISBNNotFoundException(String isbn) {
			super("ISBN에 해당하는 책이 존재하지 않습니다. - "+isbn);
		}
}
