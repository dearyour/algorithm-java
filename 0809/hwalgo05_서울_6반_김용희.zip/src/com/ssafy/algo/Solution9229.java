package com.ssafy.algo;
import java.util.Scanner;
public class Solution9229 {
				static Scanner sc = new Scanner(System.in);
				public static int solution() {

					int N = sc.nextInt();   // 과자봉지 개수 
					int M = sc.nextInt();    // 무게 합 제한 

					int max = -1;
					int[] arr = new int[1000];

					for (int t = 0; t < N; t++) {  //과자 봉지수만큼 

						arr[t] = sc.nextInt();		 // 배열에 저장한다 
					}
					for (int i = 0; i < N; i++) {		 
						for (int j = i + 1; j < N; j++) { 

							int sum = arr[i] + arr[j];   // 두개의 합
							if (sum <= M && sum > max)   // 두개합해서 무게합제한  더크거나 같고 
														// sum이 양수라면 
								max = sum;				//sum이 맥스값이다  
						}
					}
					return max;

				}

				public static void main(String[] args) {
					int T = sc.nextInt();   //테케 

					for (int cnt = 1; cnt <= T; cnt++) {
						System.out.printf("#%d %d", cnt, solution());
						System.out.println();
					}
				}
}
