package com.ssafy.product;

import java.util.ArrayList;
import java.util.Scanner;

public class ProductMgrlmpl implements IProductMgr {

	ArrayList<Product> list = new ArrayList<>();

	private Product[] tmp;

	@Override
	public void insert(Product p) {

		list.add(p);

	}
	@Override
	public void searchall() {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}
	@Override
	public void searchPnum(String num) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getPnum().equals(num)) {
				System.out.println(list.get(i));
			}
		}
		System.out.println("다시 입력해주세요");
	}
	@Override
	public void searchPname(String num) {// 상품명으로 상품을 검색 (부분검색 가능)
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getPname().contains(num)) {
				System.out.println(list.get(i));
			}
		}
	}
	@Override
	public void searchTv() {
		System.out.println("############# tv정보 #############");
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) instanceof Television) {
				System.out.println(list.get(i));

			}
		}
	}

	@Override
	public void searchRg() {
		System.out.println("############# 냉장고정보 #############");
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) instanceof Refrigerator) {
				System.out.println(list.get(i));
			}
		}
	}
	@Override
	public int price() {
		int total = 0;
		int cnt = 0;
		int pri = 0;
		for (int i = 0; i < list.size(); i++) {
			pri = list.get(i).getPrice();
			cnt = list.get(i).getcount();
			total += (pri * cnt);
		}
		return total;
	}
	@Override
	public void Tvinch() {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) instanceof Television) {
				if (((Television) list.get(i)).getInch() >= 50) {
					System.out.println(list.get(i));
				}
			}
		}
	}

	@Override
	public void RegLitter() {
		for (int i = 0; i < list.size(); i++) {
			if ((list.get(i) instanceof Refrigerator)) {
				if (((Refrigerator) list.get(i)).getLitter() >= 400) {
					System.out.println(list.get(i));
				}
			}
		}
	}
	public void DeleteNum(String num) {
		for (Product p : list) {
			if (p.getPnum().equals(num)) {
				list.remove(p);
				break;
			}
		}
	}
	@Override
	public void searchDownProduct(String num, int price) {
		int sum=0;
		for(Product p : list) {
			if(p.getPnum().equals(num)) {
				list.get(sum).setPrice(price);
			}
			sum++;
		}
	}
}
