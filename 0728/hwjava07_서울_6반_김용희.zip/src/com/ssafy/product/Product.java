package com.ssafy.product;

public class Product {
	private String pnum;
	private String pname;
	private int price;
	private int count;
	
	
	public Product(String pnum, String pname, int price, int count) {
		super();
		this.pnum = pnum;
		this.pname = pname;
		this.price = price;
		this.count = count;
	}
	
	
	public String getPname() {
		return pname;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getPrice() {
		return price;
	}
	public int getcount() {
		return count;
	}
	@Override
	public String toString() {
		return "Product [상품번호 =" + pnum + ", 상품명 =" + pname + ", 가격 =" + price + ", 재고 =" + count ;
	}

	
	
}
