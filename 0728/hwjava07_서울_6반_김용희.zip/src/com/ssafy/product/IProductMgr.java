package com.ssafy.product;

public interface IProductMgr {

	public void insert(Product p);
	
	public void searchall();
	
	public void searchPnum(String sp);
	
	public void searchPname(String sp);
	
	public void searchTv();
	
	public void searchRg();
	
	public int price();
		
	public void Tvinch();
	
	public void RegLitter();
	
	public void searchDownProduct(String num,int price);
		
	
}
