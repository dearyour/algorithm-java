package com.ssafy.product;

public class Refrigerator extends Product {
	
	private int L;
	
	public Refrigerator(String pnum, String pname, int price, int count,int Litter) {
		super(pnum, pname, price, count);
		this.L=Litter;
	}

	public int getLitter() {
		return L;
	}

	public void setLitter(int litter) {
		L = litter;
	}

	@Override
	public String toString() {
		return super.toString() +" 리터=" + L + "]" ;
	}
	

}