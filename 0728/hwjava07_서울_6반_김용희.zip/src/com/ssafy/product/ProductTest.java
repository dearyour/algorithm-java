package com.ssafy.product;

import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		ProductMgrlmpl pm = new ProductMgrlmpl();
		int check = 0;
		int m = 0;
		String sp = "";
		while (true) {
			System.out.println(
					"1/상품저장 2/상품정보 전체검색 3/상품번호로 상품검색  4/상품명으로 상품검색\n5/tv정보만 검색 6/냉장고정보만 검색 7/400L이상의 냉장고 8/50inch 이상의 티비\n9/가격변경 10/상품번호로 삭제 11/전제 재고 상품 금액  ");
			int num = sc.nextInt();
			switch (num) {

			case 1:
				System.out.println("1. tv  2. 냉장고");
				check = sc.nextInt();
				if (check == 1) {
					sc.nextLine();
					System.out.println("상품번호(String) 상품명(String) 가격(int) 재고(int) 인치(int)");
					sp = sc.nextLine();
					String[] str = sp.split(" ");
					Television tv = new Television(str[0], str[1], Integer.parseInt(str[2]), Integer.parseInt(str[3]),
							Integer.parseInt(str[4]));
					pm.insert(tv);
					break;
				} else if (check == 2) {
					sc.nextLine();
					System.out.println("상품번호(String) 상품명(String) 가격(int) 재고(int) 리터(int)");
					sp = sc.nextLine();
					String[] str = sp.split(" ");
					Refrigerator rg = new Refrigerator(str[0], str[1], Integer.parseInt(str[2]),
							Integer.parseInt(str[3]), Integer.parseInt(str[4]));
					pm.insert(rg);
					break;
				}

			case 2:
				pm.searchall();
				break;

			case 3:
				System.out.println("상품번호 입력 :");
				sp = sc.next();
				pm.searchPnum(sp);
				break;

			case 4:
				System.out.println("상품명 입력 :");
				sp = sc.next();
				pm.searchPname(sp);
				break;

			case 5:
				pm.searchTv();
				break;

			case 6:
				pm.searchRg();
				break;

			case 7:
				pm.RegLitter();
				break;
			case 8:
				pm.Tvinch();
				
				break;

			case 9:
				System.out.println("상품번호 입력:");
				sp=sc.next();
				System.out.println("변경할 가격 입력:");
				m=sc.nextInt();
				pm.searchDownProduct(sp, m);
				break;
			case 10:
				System.out.println("상품번호 입력:");
				sp=sc.next();
				pm.DeleteNum(sp);
				
				break;
			case 11:
				
				m = pm.price();
				System.out.println(m);
				break;
				
			}

		}

	}

}
