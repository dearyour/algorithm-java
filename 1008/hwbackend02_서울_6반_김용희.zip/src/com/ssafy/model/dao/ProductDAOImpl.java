package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.util.DBUtil;

public class ProductDAOImpl implements ProductDAO {

	
	private DBUtil dbUtil = DBUtil.getInstance();
	
	@Override
	public boolean insertProduct(Product product) throws SQLException {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into product(product_name,product_price,product_desc) values(?,?,?)";
				
		try {
			conn = dbUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getProduct_name());
			pstmt.setInt(2, product.getProduct_price());
			pstmt.setString(3, product.getProduct_desc());
			return pstmt.executeUpdate() > 0;
		} finally {
			dbUtil.close(pstmt,conn);
		}
	}

	
	
	public Product selectProduct(int product_no) throws SQLException { //아이디주면 아이디에 대한 사용자 가져옴, 아이디중복체크 
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;  //셀렉트 쿼리문에서 사용
		String sql = "select product_name,product_price,product_desc from product where product_no = ?";
				
		try {
			conn = dbUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, product_no);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return new Product(product_no, rs.getString(1), rs.getInt(2), rs.getString(3));
			}
		} finally {
			dbUtil.close(rs,pstmt,conn);
		}
		return null;
	}

	@Override
	public List<Product> selectProductList() throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select product_no,product_name,product_price,product_desc from product";
		ArrayList<Product> list = new ArrayList<Product>();	
		try {
			conn = dbUtil.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				list.add(new Product(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4)));
			}
		} finally {
			dbUtil.close(rs,pstmt,conn);
		}
		return list;
	}
}






