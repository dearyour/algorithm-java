package com.ssafy.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductDAO {

	boolean insertProduct(Product product) throws SQLException;
	public Product selectProduct(int product_no) throws SQLException;
	public List<Product> selectProductList() throws SQLException;
}
