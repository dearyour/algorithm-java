package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dao.ProductDAO;
import com.ssafy.model.dao.ProductDAOImpl;
import com.ssafy.model.dto.Product;

public class ProductServiceImpl implements ProductService {

	private ProductDAO productDAO = new ProductDAOImpl();
	
	@Override
	public boolean register(Product product) throws SQLException {
		// 물품존재여부 확인
		if(productDAO.selectProduct(product.getProduct_no()) != null) return false;
		//물품정보를 db에 저장
		return productDAO.insertProduct(product);
	}
	

	@Override
	public List<Product> getProductList() throws SQLException {
		return productDAO.selectProductList();
	}
	
	
}
