package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductService {

	boolean register(Product user) throws SQLException;


	List<Product> getProductList() throws SQLException;

}