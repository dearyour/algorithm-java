package com.ssafy.model.dto;

public class Product {

	private int product_no;
	private String product_name;
	private int product_price;
	private String product_desc;
	
	public Product() {
		super();
	}
	
	public Product(int product_no, String product_name, int product_price, String product_desc) {
		super();
		this.product_no = product_no;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_desc = product_desc;
	}

	public Product(String product_name, int product_price, String product_desc) {
		super();
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_desc = product_desc;
	}

	public int getProduct_no() {
		return product_no;
	}

	public void setProduct_no(int product_no) {
		this.product_no = product_no;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}

	public String getProduct_desc() {
		return product_desc;
	}

	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}

	@Override
	public String toString() {
		return "User [product_no=" + product_no + ", product_name=" + product_name + ", product_price=" + product_price
				+ ", product_desc=" + product_desc + "]";
	}

	
}
