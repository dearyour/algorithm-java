package com.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

/**
 * Servlet implementation class RegistserServlets
 */
@WebServlet("/product/register")
public class RegistserServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ProductService productService = new ProductServiceImpl();

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		String product_name = request.getParameter("product_name");
		int product_price = Integer.parseInt(request.getParameter("product_price"));
		String product_desc = request.getParameter("product_desc");
		
		try {
			boolean flag = productService.register(new Product(product_name, product_price, product_desc));
			
			if(flag) {
				// 로그인화면으로 이동
				response.sendRedirect(request.getContextPath()+"/product/list");
				return;
			}else {
				request.setAttribute("errorMessage", "아이디를 가진 회원이 이미 존재합니다.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("errorMessage", e.getMessage());
		}
		
		request.getRequestDispatcher("/error.jsp").forward(request, response);
		return;
	}

}
