package com.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

/**
 * Servlet implementation class ListServlets
 */
@WebServlet("/product/list")
public class ListServlets extends HttpServlet {
       
	private static final long serialVersionUID = 1L;
	private final ProductService productSerivce = new ProductServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			request.setAttribute("productList",productSerivce.getProductList());
			request.getRequestDispatcher("/product_list.jsp").forward(request, response);
			return;
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("errorMessage",e.getMessage());
			request.getRequestDispatcher("/error.jsp").forward(request, response);
			return;
		}
	}
}
