package com.ssafy.algo;

import java.util.Scanner;

public class Solution2563_김용희 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();					//색종이수 
		int[][] paper = new int[100][100];		//초기값이 0 
		//paper[y][x] == 도화지의 (x,y)격자를 덮는 색종이의 수 
		
		for(int i=0; i<n; i++) {
			// 각 색종이에 대한 처리
			// (sx, sy) == 색종이의 왼쪽 아래 좌표 
			int sx = sc.nextInt();
			int sy = sc.nextInt();
			
			for(int x = sx; x <= sx + 9; x++) {
				for(int y = sy; y <= sy + 9; y++) {
					//이 색종이가 덮는 모든 격자에 대하여 한번씩 실행 
					paper[y][x] ++;
					// 이 격자를 덮는 색종이의 수를 카운트 업 
				}
			}
		}
		//paper배열이 의미에 맞게 완성
		int count = 0;
		for(int y =0 ; y<= 99; y++) {
			for(int x =0; x<=99; x++) {
				// 도화지 상에 존재하는 1만개의 모든 격자에 대해서 실행
				
				if(paper[y][x] >= 1) {
					//하나 이상의 색종이가 덮고 있는 모든 격자에 대해 실행
					count++;
				}
			}
		}
		
		//count = 하나 이상의 색종이가 덮고 있는 격자의 수 
		System.out.println(count);
	}
}



