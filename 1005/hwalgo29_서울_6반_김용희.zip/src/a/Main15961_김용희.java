package a;

import java.util.Scanner;

public class Main15961_김용희 {
//	static int N,d,k,c ;
//	static int arr[], visited[];
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt(); //초밥벨트 접시의 수 
		int d = sc.nextInt(); //초밥의 가짓수 
		int k = sc.nextInt(); //슬라이딩 윈도우 접시  k
		int c = sc.nextInt(); //쿠폰번호 
		
		int[] arr = new int[N];
		int slide[] = new int[d+1];
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		int sum =0, max =0;
		for (int i = 0; i < k; i++) {
			if(slide[arr[i]] ==0) sum++;
			slide[arr[i]]++;
		}
		max =sum;
		
		for (int i=1; i <arr.length; i++) {
			if (max <= sum) {
				if (slide[c] ==0)
					max =sum+1; //쿠폰c가들어있지 않으면 최대가지수 +1
				else 
					max =sum; //쿠폰 c 들어있음  걍출력 
			}
			//슬라이딩 이동하면서 맨앞은 0으로 초기화 새로운맨뒤는+1
			
			slide[arr[i-1]]--;  //슬라이딩 가장 맨앞 초밥뺸다.
			if(slide[arr[i-1]]==0 ) sum --;
			
			//순환하니까 범위넘어가면 N으로 나머지 연산 
			//기존에없던 음식이면 가지수 ++ 
			slide[arr[(i + k - 1) % N]]++; //슬라이딩 가장 뒤 초밥추가
			if(slide[arr[(i+ k -1 ) % N]]==1)sum++; //슬라이딩이 1이면 새로추가된 초밥
				
			}
			System.out.println(max);
		}
}
/*
8 30 4 30
7
9
7
30
2
7
9
25
*/