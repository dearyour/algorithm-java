package a;
import java.util.Scanner;
public class Solution5643_김용희 {
	static int N;
	static int M;
	static int[][] dist;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int tc = 1; tc <= T; tc++) {
			N = sc.nextInt();  //학생수
			M = sc.nextInt();  //간선수 
			dist = new int[N][N];
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (i == j)
						dist[i][j] = 0;
					else
						dist[i][j] = -1;
				}
			}
			for (int i = 0; i < M; i++) {
				int a = sc.nextInt();		
				int b = sc.nextInt();
				dist[a - 1][b - 1] = 99;
			}
			for (int k = 0; k < N; k++) {   //경유지 
				for (int i = 0; i < N; i++) {  //출발지
					for (int j = 0; j < N; j++) {  //도착지
						if (i == j)
							continue;  
						if (dist[i][k] != -1 && dist[k][j] != -1) {
							dist[i][j] = 99; 
						}
					}
				}
			}
			int res = 0;
			for (int i = 0; i < N; i++) {
				int cnt = 0;
				for (int j = 0; j < N; j++) { 
					if (dist[i][j] == 99 || dist[j][i] == 99)
						cnt++;
				}
				
				//자신보다 작은 친구와 큰 친구의 합이 N-1 이라면 자신이 몇 번째인지 알 수 있음
				if (cnt == N - 1)
					res++;
			}
			System.out.println("#"+tc+" " + res);
		} 
	}
}


