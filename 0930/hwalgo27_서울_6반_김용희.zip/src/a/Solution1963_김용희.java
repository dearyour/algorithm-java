package a;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

// 1) 최초맨홀 -> bfs탐색 -> 사방탐색
// 좌표 영역 내부
// 좌표가 미방문 => visited[][]
//map값이 파피여야함 0이 아니여야함
// 새로운 지점 과 현재 지점 은 파이프로 연결되어있어야한다.  (현재 방향 +2) % 4  = 새로운지점   // 1이면 3 0이면 2랑 연결되어야함 //상우하좌
// L시간 까지만 탐색 - > bfs의 너비   ,,, 1시간부터 시작  
public class Solution1963_김용희 {
		static int TC, N, M, row, col, time;
		static int[][] map;
		static int answer;
		
		static int[] dr = {-1, 0, 1, 0};
		static int[] dc = { 0, 1, 0, -1};  //상 우 하 좌
		
		static boolean[][] pipes = {{}, 
				{true, true, true, true},    //1번파이프  상우좌하
				{true, false, true, false},  // 상하
				{false, true, false, true},  // 우좌
				{true, true, false, false},  // 상우
				{false, true, true, false},  // 우하
				{false, false, true, true},  // 하좌
				{true, false, false, true}   // 상좌 
		};
		
		
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = null;
		StringBuilder sb = new StringBuilder();
		
		TC = Integer.parseInt(br.readLine());
		
		for (int t = 1; t <= TC; t++) {
			st = new StringTokenizer(br.readLine());
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			row = Integer.parseInt(st.nextToken());
			col = Integer.parseInt(st.nextToken());
			time = Integer.parseInt(st.nextToken());
			
			map = new int[N][M];
			for (int r = 0; r < N; r++) {
				st = new StringTokenizer(br.readLine()," ");
				for (int c = 0; c < M; c++) {
					map[r][c] = Integer.parseInt(st.nextToken());
				}
			}
			answer =0;
			bfs();
			
			sb.append("#").append(t).append(" ").append(answer).append("\n");
		}
		System.out.println(sb);
	}
	
	static void bfs() {
		Queue<Point> queue = new LinkedList<>();
		boolean[][] visited = new boolean[N][M];
		Point start = new Point(row,col,1); // 처음부터 한시간 이동
		visited[start.r][start.c] = true;
		queue.offer(start);
		
		while(!queue.isEmpty()) {
			Point q = queue.poll();
			
			if(q.cnt >time) {  //이동횟수가 제한시간값 이상이되면 리턴 
				return;
			}
			//그렇지않다면 도둑이 있을수있는지점 
			answer++; 
			
			for (int d = 0; d < 4; d++) {
				if(pipes[q.pipe][d]) { //현재 포인트에 d쪽이 열려있나 
					int nr =q.r + dr[d];  
					int nc =q.c + dc[d];
					
					//안이 방문하지않고 파이프라면 이동
					if(0<=nr && nr<N && 0<=nc && nc< M && !visited[nr][nc]&& map[nr][nc]>0) { //범위안 방문안하고 파이프있니 
						int nt =map[nr][nc];  //파이프 정보를가져온다 
						if(pipes[nt][(d+2) % 4]) {  //파이프 새로운타입이 끝과시작이같은지 1->3 , 2->0
							visited[nr][nc] = true;
							queue.offer(new Point(nr, nc, q.cnt+1));
						}
					}
				}
			}
		}
		
	}
	
	static class Point {
		int r, c, cnt , pipe;   //cnt는 bfs의 너비
		
		public Point(int r, int c, int cnt) {
			this.r =  r;
			this.c =  c;
			this.cnt = cnt;
			pipe = map[r][c];
		}
		
//		public String toString() {
//			return "[(" + r + "," + c + ", d=" + cnt + ", t=" + pipe + "]";
//		}
	}

}

/*
1
5 6 2 1 3      
0 0 5 3 6 0
0 0 2 0 2 0
3 3 1 3 7 0
0 0 0 0 0 0
0 0 0 0 0 0
*/