package com.ssafy.mvc.model.repo;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.ssafy.mvc.model.dto.Emp;

@Repository
public interface EmpRepo {
	int insert(Emp emp);
	List<Emp> search();
	Emp select(int num);
	int delete(int num);
	int update(Map<String,Integer> map);
}
