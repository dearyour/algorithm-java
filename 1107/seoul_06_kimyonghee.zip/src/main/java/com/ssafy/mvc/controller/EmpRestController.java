package com.ssafy.mvc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.mvc.model.dto.Emp;
import com.ssafy.mvc.model.service.EmpService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin("*")
@RequestMapping("/empapi")
public class EmpRestController {
	@Autowired
	private EmpService svc;
	
    private ResponseEntity<?> exceptionHandling(Exception e){
        e.printStackTrace();
        return new ResponseEntity<String>("Exception: "+e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);//500
    }
    
    @PostMapping("/emp")
    @ApiOperation(value = "Emp 객체를 등록한다.", response = Integer.class)
    public ResponseEntity<?> insert(@RequestBody Emp emp){
        try {
            int result=svc.insert(emp);
            if(result==1) return new ResponseEntity<Integer>(result,HttpStatus.CREATED);//201 결과값
            else                 return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);//204 http상태 
        }catch(Exception e) {
            return exceptionHandling(e);
        }
    }
	
    @GetMapping("/emp")
    @ApiOperation(value = "Emp 객체의 목록을 반환한다.", response = Emp.class)
    public ResponseEntity<?> search(){
        try {
            List<Emp> emps=svc.search();
            if(emps!=null && emps.size()>0) return new ResponseEntity<List<Emp>>(emps,HttpStatus.OK);//200
            else                            return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);//204
        }catch(Exception e) {
            return exceptionHandling(e);
        }
    }
    
    @GetMapping("/emp/{num}")
    @ApiOperation(value = "{num}에 해당하는 Emp 정보를 반환한다.", response = Emp.class)
    public ResponseEntity<?> select(@PathVariable int num){
        try {
            Emp emp=svc.select(num);
            if(emp!=null) return new ResponseEntity<Emp>(emp,HttpStatus.OK);//200
            else          return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);//204
        }catch(Exception e) {
            return exceptionHandling(e);
        }
    }
    @DeleteMapping("/emp/{num}")
    @ApiOperation(value = "{num}에 해당하는 Emp 객체를 삭제한다.", response = Integer.class)
    public ResponseEntity<?> delete(@PathVariable int num){
        try {
            int result=svc.delete(num);
            if(result==1) return new ResponseEntity<Integer>(result,HttpStatus.CREATED);//201
            else                 return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);//204
        }catch(Exception e) {
            return exceptionHandling(e);
        }
    }
	 @PutMapping("/emp")
	 @ApiOperation(value = "Emp 객체를 수정한다.", response = Integer.class)
	    public ResponseEntity<?> update(@RequestBody Map<String,Integer> map){
	        try {
	            int result=svc.update(map);
	            if(result==1) return new ResponseEntity<Integer>(result,HttpStatus.CREATED);//201
	            else                 return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);//204
	        }catch(Exception e) {
	            return exceptionHandling(e);
	        }
	    }
	
}
