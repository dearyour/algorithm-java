package com.ssafy.mvc.model.dto;

public class Emp {
	private int num;
	private String name;
	private int salary;
	
	public Emp() {
		
	}
	public Emp(int num, String name, int salary) {
		this.num = num;
		this.name = name;
		this.salary = salary;
	}
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Emp [num=" + num + ", name=" + name + ", salary=" + salary + "]";
	}
}
