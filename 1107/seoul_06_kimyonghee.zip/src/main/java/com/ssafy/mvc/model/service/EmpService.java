package com.ssafy.mvc.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ssafy.mvc.model.dto.Emp;

@Service
public interface EmpService {
	int insert(Emp emp);
	List<Emp> search();
	Emp select(int num);
	int delete(int num);
	int update(Map<String,Integer> map);
}
