package com.ssafy.mvc;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@MapperScan("com.ssafy.mvc.model.repo")
@SpringBootApplication
public class Seoul06KimyongheeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Seoul06KimyongheeApplication.class, args);
	}

}
