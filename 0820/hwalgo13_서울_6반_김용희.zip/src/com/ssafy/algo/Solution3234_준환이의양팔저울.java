package com.ssafy.algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

//무게추를 배치: 순서 있냐없냐 순서있으면 순열 순성벗으면 조합 //이건 순열 완탐문제임  
//가지치기 : 중간에라도 오른쪽 sum> 왼쪽sum 이면 뒤에조사안함 
//스태틱,파라미터: 변수타입에 따라 pass / fail 결정
//왼    오 
public class Solution3234_준환이의양팔저울 {
	static BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	static StringBuilder output = new StringBuilder();
	static StringTokenizer tokens = null;
	
	static int T;
	static int N;
	static int ans;
	//미리 구해놓을 2의 거듭제곱
	static int[] pow = new int[10];
	//미리 구해놓을 factorial 값
	static int[] fac = new int[10];
	//전체 추의 무게
	static int totalWeight; // 2번째 가지치기 
	// 전체 추의 정보
	static int[] weights;	
	
	static boolean[] visited; // 순열
	
	static void init() {
		pow[0] = 1;
		fac[0] = 1;
		for(int i =1; i<=9; i++){
			pow[i] = pow[i - 1] *2;
			fac[i] = fac[i - 1] *i;
		}
//		System.out.println(Arrays.toString(pow));
		
	}
	public static void main(String[] args) throws IOException {
		init();
		
		input = new BufferedReader(new InputStreamReader(System.in));
		
		T= Integer.parseInt(input.readLine());
		for (int t=1; t<=T; t++) {
			
			N= Integer.parseInt(input.readLine());
			weights = new int[N];
			visited = new boolean[N];
			
			totalWeight = 0;
			tokens = new StringTokenizer(input.readLine());
			for(int n=0; n<N; n++) {
				weights[n] =Integer.parseInt(tokens.nextToken());
				totalWeight += weights[n];
			}
			// 입력완료
				ans =0;
			//각 요소들을 배치해 본다.
				perm(0, 0, 0, totalWeight);
				
				output.append("#").append(t).append(" ").append(ans).append("\n");
			}
			System.out.println(output);
		}
	
		
		//올라가는 추들은 순서가 있다 --> 순열
		// 오른쪽 무게의 합이 왼쪽 무게의 합보다 커지지 않는경우
		public static void perm(int idx, int leftSum, int rightSum, int remain) { //레프트라이트 가지치기 조건 ,리메인은 가지치기 후 남아있는 남아있는 추 0
			//남은 것들을 모두 오른쪽에 놔도 왼족무게 이하임
			if(leftSum >= remain + rightSum) {  //모두 오른쪽에 넣음 
				ans += pow[N-idx] * fac[N-idx]; //남은개수
				return;
			}
			//끝가지 가보면 탈출
			if(idx == N) {
				ans++;
				return;
			}
			
			//아니면 재귀 진행
			for(int n = 0 ; n< N ; n++) {
				if(!visited[n]) {
					//이번추를 사용해보자
					visited[n]=true;
					int curWeight = weights[n];
					//왼쪽에는 언제나 돌릴수있음
					perm(idx +1 ,leftSum + curWeight, rightSum, remain - weights[n]);
					//무게가 괜찮으면 오른쪽에도 놓아봄
					if(rightSum + curWeight <= leftSum) {
						perm(idx +1, leftSum, rightSum + curWeight, remain- weights[n]);
					}
					//이 추 말고 다른 추를 놔보자.
					visited[n] =false;
					

				}
			}
			}
}
/*
3
3
1 2 4
3
1 2 3
9
1 2 3 5 6 4 7 8 9
 */
