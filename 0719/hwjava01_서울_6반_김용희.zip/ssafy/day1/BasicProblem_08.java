package com.ssafy.day1;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_08 {

    public static void main(String[] args) {
    	//local변수는 사용전에 초기화 필요 int i=0; 
        int i;

        System.out.println(i);

    }

}
