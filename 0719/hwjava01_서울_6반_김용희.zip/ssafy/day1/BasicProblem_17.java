package com.ssafy.day1;

/**
 * @since 2021. 7. 12.
 */
public class BasicProblem_17 {
    public static void main(String[] args) {
        int i1 = Integer.MAX_VALUE;
        
        int i2 = i1+1;
        
        System.out.println(i2);
    }
}
