package com.ssafy.day1;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_12 {
    public static void main(String[] args) {
        string s1 = "Hello";
        String s2 = "Hello";
        String s3 = new String("Hello");
        char[] s4 = "Hello";
    }
}
