package com.ssafy.day1;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_11 {
    public static void main(String[] args) {
        // A	,,,,, byte 8비트 int는 32비트 명시적변환을해야함
    	{
            int i = 10;
            byte b = (byte)i;
        }
        
        // B
        {
            byte b = 10;
            int i = b;          
        }
    }
}
