package com.ssafy.day1;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_14 {
    public static void main(String[] args) {

        int k = 66;
        char c = (char) k;
        System.out.println(c);
        
        c = 'A';
        k = c;
        System.out.println(k);
        
        int i = 10 / 3;
        System.out.println(i);
    
        float f = 10 / 3;
        System.out.println(f);
        
        float f2 = 10f / 3F;
        System.out.println(f2);

        double d = 10d / 3D;
        System.out.println(d);
        
        System.out.println( ( 10 / 3 ) * 3 ); 
    }
}
