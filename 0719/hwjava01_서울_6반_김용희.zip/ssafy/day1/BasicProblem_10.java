package com.ssafy.day1;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_10 {
   
    public static void main(String[] args) {
        final int i = 0;
        //final은 상수  초기화후 다른숫자못넣음 
        i = 10;
        System.out.println(i);
    }
}
