package com.ssafy.day1;

public class homework3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
