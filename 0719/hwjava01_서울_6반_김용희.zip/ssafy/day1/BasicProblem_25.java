package com.ssafy.day1;

import java.util.Random;

/**
 * @since 2021. 7. 4.
 */
public class BasicProblem_25 {
    public static void main(String[] args) {
        int a = 20;
        String grade = null;
        /*
        if (a >= 19) {
            grade = "성인";
        } else if (a >= 13) {
            grade = "청소년";
        } else if (a >= 6) {
            grade = "아동";
        } else {
            grade = "유아";
        }*/

        /*if (a >= 6) {
            grade = "아동";
        } else if (a >= 13) {
            grade = "청소년";
        } else if (a >= 19) {
            grade = "성인";
        } else {
            grade = "유아";
        }*/

        /*if (a >= 19)
            grade = "성인";
        else if (a >= 13)
            grade = "청소년";
        else if (a >= 6)
            grade = "아동";
        else
            grade = "유아";
         */
        
        /* if (a >= 19)
            grade = "성인";
            System.out.println("SSAFY 지원 가능");
        else if (a >= 13)
            grade = "청소년";
        else if (a >= 6)
            grade = "아동";
        else
            grade = "유아";*/
            
        
    }
}
