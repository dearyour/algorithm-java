package com.ssafy.object;

public class Person {
	
	String name;
	int age;
	boolean isHungry;
	
	static int total;
	int order;
	
	static {
		System.out.println("person static initializer..");
		total = 0;
	}
	// 생성자 : 객체의 초기화를 담당하는 특별한 메소드 (초기화 코드 재사용 )   
	// 작성규칙 :
	// 1. 클래스 이름과 같게 한다.
	// 2. 리턴 타입 개념이 없다.
	// 3. 여러개 정의 가능 : 다중 정의가 가능 (오버로딩 가능)
	// 4. 부모의 생성자가 자식의 생성자가 될수는 없다 ( 클래스이름이 같지않기 때문에 )  
	// 5. 클래스 안에 생성자가 1개도 없을경우 자동으로 컴파일러에 의해 기존 생성자가 추가된다 . 
	// ==> 이점 : 상황에 따라 객체 생성을 다양하게 할 수 있다.
	
	
	Person(String name, int age)  {
		this();
		this.name = name;
		this.age = age; 
	}
	Person(String name, int age, boolean isHungry) {
		
		this(name,age);
		this.isHungry = isHungry;
	}
//	Person(String name, int age, boolean isHungry) {
//		order = ++total;
//		this.name = name;
//		this.age = age;
//		this.isHungry = isHungry;
//	}
	Person(){
		order = ++total;
	}

	void eat() {
		System.out.println("냠냠 맛있게 먹어요..");
		isHungry = false;
	}
	void work() {
		System.out.println("열심히 일해요..");
		isHungry = true;
	}
	public String toString() {
		return "["+order+"/"+total+"] "+name+"/"+age+"/"+isHungry+"/"+total+"명";
	}
	

	   
}
