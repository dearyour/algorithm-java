package com.ssafy.object;

public class PersonTest {

	public static void main(String[] args) {
		Person p1 = new Person("김재환",26,true);
		Person p2 = new Person("나준엽",24);
		
		
		
		System.out.println(p1.toString());
		System.out.println(p2.toString());
//		System.out.println(p1.name+"/"+p1.age+"/"+p1.isHungry);
//		System.out.println(p2.name+"/"+p2.age+"/"+p2.isHungry);
//		
		Person p3 = new Person("이동욱",15,true);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
	
		p2.isHungry= true;
		System.out.println(p1.name+"/"+p1.age+"/"+p1.isHungry);
		System.out.println(p2.name+"/"+p2.age+"/"+p2.isHungry);
		
		 
		
	}

}
