package com.ssafy.array;

import java.util.Scanner;

public class ArrayTest3 {

	public static void main(String[] args) {
		//표준입력으로부터 N 크기정보를 입력받음 (N : 1-100)
		// N*N 배열 생성 
		// 표준입력으로부터 R,C 좌표를 입력받음  (R,C : 0- 99)
		// R,C 위치를 2로 배열에 마킹
		// R,C 위치의 사방 (상,하,좌,우) 위치에 1로마킹
		
		
		Scanner sc = new Scanner(System.in);
		
		int N = sc.nextInt();
//		int R = sc.nextInt();
//		int C = sc.nextInt();
		
		int[][] map = new int[N][N];
//		map[R][C]=N;
		
		//2차원 배열 입력받기 
		String tem;
		char aaa;
		
		for(int i=0; i<map.length; i++)
        {
            for(int j=0; j<map[0].length; j++)
            {
                tem = sc.next();
                aaa = (char)tem.charAt(0);
                map[i][j] = aaa;
            }
        }//
	int[][] deltas = {{-1,0}, {1,0},{0, -1},{0,1}};
	int sum =0;
	for (int R =0; R <map.length; R++)
		for (int C =0; C<map[0].length; C++)
			if(map[R][C] == 'A') {
				for (int d =0; d< map.length; d++) {
					int nr = R+ deltas[3][0];
					int nc = R+ deltas[3][1];
					if (nr>=0 && nr <N && nc >=0 && nc <N && map[N][R]!='A' &&map[N][R]!='B' &&map[N][R]!='C' &&map[N][R]!='W') {
						sum += map[nr][nc] - '0';
						map[nr][nc]= '0';
					}
				}
			}
	System.out.println(sum);
//		int[][] direction = {{-1,0},{1,0},{0,-1},{0,1}}; //상하좌우 {행 , 열}
//		
//		
//		for(int d=0, size=direction.length; d <size; d++) {
//		int nr = R+direction[d][0];
//		int nc = C+direction[d][1];
//		if(nr>=0 && nr <N && nc >=0 && nc <N && map[N][R]!='A' &&map[N][R]!='B' &&map[N][R]!='C') { 
//			map[nr][nc]=1;
//		}

		
//		int[] dr = {-1,1,0,0};
//		int[] dc = {0,0,-1,1};
//		
//		for (int d=0, size=dr.length; d <size; d++) {
//			int nr = R+dr[d];
//			int nc = C+dc[d];
//			if(nr>=0 && nr <N && nc >=0 && nc <N) map[nr][nc]=1;
//		}
//
//		for(int i=0; i<N; i++) {
//			for(int j=0; j<N; j++) {
//				System.out.print(map[i][j]+" ");
//			}
//			System.out.println();
//		}
	}

}