package com.ssafy.array;

import java.util.Scanner;

public class ArrayTest1 {

	public static void main(String[] args) {
		//표준입력으로부터 N 크기정보를 입력받음 (N : 1-100)
		// N*N 배열 생성 
		// 표준입력으로부터 R,C 좌표를 입력받음  (R,C : 0- 99)
		// R,C 위치를 2로 배열에 마킹
		// R,C 위치의 사방 (상,하,좌,우) 위치에 1로마킹
		
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int R = sc.nextInt();
		int C = sc.nextInt();
		
		int[][] map = new int[N][N];
		//1. R.C위치를 2로 배열에 마킹
		map[R][C]=2;
		//2. R,C 위치의 사방 위치에 1로 마킹 
		//상
		if(R-1>=0) map[R-1][C] = 1;
		//하
		if(R+1<N) map[R+1][C]= 1;
		//좌
		if(C-1>=0) map[R][C-1]= 1;
		//우
		if(C+1<N) map[R][C+1]= 1;
		
		//마킹 상태 출력
		for(int i=0; i<N; i++) {
			for(int j=0; j<N; j++) {
				System.out.print(map[i][j]+" ");
			}
			System.out.println();
		}
	}
}
