package com.ssafy.array;

import java.util.Scanner;

public class ArrayTest2 {

	public static void main(String[] args) {
		//표준입력으로부터 N 크기정보를 입력받음 (N : 1-100)
		// N*N 배열 생성 
		// 표준입력으로부터 R,C 좌표를 입력받음  (R,C : 0- 99)
		// R,C 위치를 2로 배열에 마킹
		// R,C 위치의 사방 (상,하,좌,우) 위치에 1로마킹
		
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int R = sc.nextInt();
		int C = sc.nextInt();
		
		int[][] map = new int[N][N];
		//1. R.C위치를 2로 배열에 마킹
		map[R][C]=2;
	 
		
		
		int[] dr = {-1,1,0,0};
		int[] dc = {0,0,-1,1};
		
		for (int d=0, size=dr.length; d <size; d++) {
			int nr = R+dr[d];
			int nc = C+dc[d];
			if(nr>=0 && nr <N && nc >=0 && nc <N) map[nr][nc]=1;
		}
		//////int[][] direction = new direction[4][2]
//			    int[][] direction = {{-1,0},{1,0},{0,-1},{0,1}}; //상하좌우 {행 , 열}
				//2. R,C 위치의 사방 위치에 1로 마킹
//(방법2)
//		for(int d=0, size=direction.length; d <size; d++) {
//			int nr = R+direction[d][0];
//			int nc = C+direction[d][1];
//			if(nr>=0 && nr <N && nc >=0 && nc <N) map[nr][nc]=1;
//		} 
		
//(방법3
		  //for(int d=0, size=direction.length; d <size; d++) {
		  //map[R+direction[d][0]][C+direction[d][1]] = 1; } 경계 범위 안에 입력받을때는 이것으로(하지만 경계벗어남 대처안됨)
		  //  =   map[R+@][C+@]
		
		//마킹 상태 출력
		for(int i=0; i<N; i++) {
			for(int j=0; j<N; j++) {
				System.out.print(map[i][j]+" ");
			}
			System.out.println();
		}
	}
}
