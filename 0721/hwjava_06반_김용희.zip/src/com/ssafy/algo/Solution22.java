package com.ssafy.algo;

import java.util.Scanner;

public class Solution22 {
	static long Answer;
	static int N, S;
	static int[][] dir = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
	


	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		int T=sc.nextInt();//케이스 수

		for(int test_case=1; test_case<=T; test_case++){
			N=sc.nextInt(); //배열 크기 
			int[][] map=new int[N][N];

			S=sc.nextInt();//소금쟁이수
			int[][] unit=new int[S][3];
			for(int k=0; k<S; k++){
				unit[k][0]=sc.nextInt();
				unit[k][1]=sc.nextInt();
				unit[k][2]=sc.nextInt();
			}
	
			Answer = 0;
			
			for(int k=0; k<S; k++) {
				int x = unit[k][0];
				int y = unit[k][1];
				
				if(map[x][y] == 1) {
					continue;
				}else {
					for(int j=3; j>0; j--) {
						int mx = j*dir[unit[k][2]-1][0];
						int my = j*dir[unit[k][2]-1][1];
							
						if((x+mx>=0&&x+mx<map.length) &&(y+my>=0 && y+my<map.length)) {
							if(map[x+mx][y+my] == 0) {
								map[x+mx][y+my] = 1;
								map[x][y] = 0;
							}else {
								map[x][y] = 0;
							}
						}else {
							map[x][y] = 0;
						}
						x = x+mx;
						y = y+my;
						x = bound(x, map);
						y = bound(y, map);
					}
				}
			}
			

			for(int[] a : map) {
				for(int b : a) {
					if(b == 1) {
						Answer++;
					}
				}
			}
			
			System.out.println("\n#"+test_case+" "+Answer);
			
		}
	}
	public static int bound(int x, int[][] map) {
		if(x<0) return 0;
		if(x>=map.length) return map.length-1;
		return x;
	}

}
