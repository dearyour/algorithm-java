
use dbtest;

create table product(
pcode int(4),
pname varchar(10) not null,
price int(10) not null,
primary key(pcode));


desc product;

insert into product values('1','tv','200000');
insert into product values('2','ipone','350000');
insert into product values('3','galaxy','300000');
insert into product values('4','ipad','250000');
insert into product values('5','airpods','150000');


update product set price = price*0.85 ;

select * from product;

update product set price = price*0.80 where pname = 'tv';

select sum(price) from product ;
