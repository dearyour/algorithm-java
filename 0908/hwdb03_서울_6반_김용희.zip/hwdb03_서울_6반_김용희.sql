#1
SELECT count(Code) 전체, count(IndepYear) as"독립 연도 보유"  FROM country;

#2
select sum(LifeExpectancy) 합계, avg(LifeExpectancy) 평균, 
	    max(LifeExpectancy) 최대, min(LifeExpectancy) 최소 from country;

#3
select Continent , Count(continent) "국가 수" , sum(population) "인구 수"
from country 
group by continent
ORDER BY Count(continent) DESC;


#4
select Continent, Sum(SurfaceArea) "표면적 합"
from country
group by continent
order by sum(surfaceArea) desc;

#5
select continent , sum(gnp) "gnp 합"
from country
group by continent
having sum(Population) >= 50000000
order by sum(gnp) desc;


#6
select continent, sum(Population) "gnp 합"
from country 
group by continent
having sum(Population) >= 50000000 
and sum(GNP)>=5000000;


#7
select indepyear , sum(continent)
from country
group by indepyear
having sum(continent)>10;