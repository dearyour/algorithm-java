package com.ssafy.test;

import java.util.Scanner;

import com.ssafy.product.Product;
import com.ssafy.product.Refrigerator;
import com.ssafy.product.Television;

import com.ssafy.test.ProductMgr;

public class ProductTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ProductMgr pm = new ProductMgr();
		int Num = 0;
		int va=0;
		String sp="";
		while (true) {
			System.out.println("1/상품저장 2/상품정보 전체검색 3/상품번호로 상품검색 \n4/상품명으로 상품검색5/tv정보만 검색 6/냉장고정보만 검색 \n7/상품번호로 상품 삭제 8/전체 재고 상품금액  9/냉장고리터합계");
			int num = sc.nextInt();
			switch (num) {

			case 1:
				System.out.println("1.tv  2.냉장고");
				Num = sc.nextInt();
				if (Num == 1) {
					sc.nextLine();
					System.out.println("상품번호(String) 상품명(String) 가격(int) 재고(int) 인치(int)");
					sp = sc.nextLine();
					String[] str = sp.split(" ");
					Television tv = new Television(str[0], str[1], Integer.parseInt(str[2]), Integer.parseInt(str[3]),
							Integer.parseInt(str[4]));
					pm.insert(tv);
					break;
				} else if (Num == 2) {
					sc.nextLine();
					System.out.println("상품번호(String) 상품명(int) 가격(int) 재고(int) 리터(int)");
					sp = sc.nextLine();
					String[] str = sp.split(" ");
					Refrigerator rg = new Refrigerator(str[0], str[1], Integer.parseInt(str[2]),
							Integer.parseInt(str[3]), Integer.parseInt(str[4]));
					pm.insert(rg);
					break;
				}
			case 2:
				Product[] result = pm.searchall();
				for (int i = 0; i < result.length; i++) {
					if (result[i] != null) {
						System.out.println(result[i]);
					}
				}
				break;
			case 3:
				System.out.println("상품번호 입력 :");
				sp=sc.next();
				Product temp=pm.searchPnum(sp);
				System.out.println(temp.toString());
				break;
			case 4:
				System.out.println("상품명 입력 :");
				sp=sc.next();
				Product [] temp1 =pm.searchPname(sp);
				for(int i=0;i<temp1.length; i++) {
					if(temp1[i] != null) {
					System.out.println(temp1[i].toString());
					}
				}
				break;
			case 5:
				String temp2=pm.searchTv();
				System.out.println(temp2.toString());
				break;
			case 6:
				String temp3=pm.searchRg();
				System.out.println(temp3.toString());
				break;
			case 7:
				System.out.println("삭제할 상품번호 : ");
				String s =sc.next();
				pm.deletePnum(s);
				break;
			case 8:
				va=pm.price();
				System.out.println(va);
				break;
			case 9:
				va=pm.sumReg();
				System.out.println("냉장고리터합계 : "+va+"리터");
				break;
				
				
			}
		} 
	}

}