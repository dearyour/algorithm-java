package com.ssafy.test;

import java.util.Scanner;

import com.ssafy.product.Product;
import com.ssafy.product.Refrigerator;
import com.ssafy.product.Television;

public class ProductMgr {

	private Product[] prod = new Product[50];
	private Product[] tmp ;
	private int idx;
	
	public void insert(Product pro) { // 배열에 입력
		prod[idx++] = pro;

	}
	public Product[] searchall() { // 상품정보 전체 검색

		return prod;
	}

	public Product searchPnum(String pnum) { // 상품번호 상품 검색
		for (int i = 0; i < idx; i++) {
			if (prod[i].getPnum().equals(pnum)) {
				return prod[i];
			}
		}
		System.out.println("입력한 상품이 없습니다");
		return null;

	}

	public Product[] searchPname(String pname) { // 상품명 상품 검색 
		tmp=new Product[idx];
		int num=0;
		for (int i = 0; i < idx; i++) {
			if (prod[i].getPname().contains(pname)) {
				tmp[num++]=prod[i];
			}
		}
		return tmp;
	}

	public String searchTv() { // tv정보 검색
		String out = "";
		System.out.println("############## tv정보 ############## ");
		for (int i = 0; i < idx; i++) {
			if (prod[i] instanceof Television) {
				out += prod[i].toString() + "\n";
			}
		}
		return out;
	}

	public String searchRg() { // 냉장고 검색
		String out1 = "";
		System.out.println("############## 냉장고정보 ##############");
		for (int i = 0; i < idx; i++) {
			if (prod[i] instanceof Refrigerator) {
				out1 += prod[i].toString() + "\n";
			}
		}
		return out1;
	}
	
	public void deletePnum(String num) { // 상품번호로 상품을 삭제
		int del = 0, index = 0;
		while (prod[del] != null) {
			if (prod[del].getPnum().compareTo(num) == 0) {
				index = del;
				
			}
			del++;
		}
		prod[index] = prod[del - 1];
		prod[del - 1] = null;
	}

	
	public int price() { // 전체 재고 상품 금액
		int total = 0;
		int cnt = 0;
		int pri = 0;
		for (int i = 0; i < idx; i++) {
			pri = prod[i].getPrice();
			cnt = prod[i].getcount();
			total += (pri * cnt);
		}
		return (total);
	}
	
	
	  public Product[] searchDownProduct(String name,int price) { //상품명에서 가격 입력해서 그 가격보다  작은 동일 상품
		 tmp =new Product[idx];
		 int num=0;
		  for (int i = 0; i<idx;i++) {
			  if(prod[i].getPname().contains(name)) {
				  if(price>=prod[i].getPrice()) {
					  tmp[num++] = prod[i];	  
				  }
			  }
		  }
		return tmp; 
	  }
		public int sumReg() {  //냉장고 리터 합계
			int sum=0;
			for(int i=0;i<idx;i++) {
				if(prod[i] instanceof Refrigerator) {
					sum += ((Refrigerator)prod[i]).getLitter();
				}
			}
			
			return sum;
		}
		
	  
	

}
