package com.ssafy.product;

public class Television extends Product {
	
	private int inch;
	
	public Television(String pnum, String pname, int price, int count,int inch) {
		super(pnum, pname, price, count);
		this.inch=inch;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}
	
	@Override
	public String toString() {
		return super.toString() +" 인치="+inch+"]";
	}
	
	
}