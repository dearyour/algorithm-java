SELECT * FROM emp;
select * from dept;

-- 1
select ename, job, sal 
from emp e, dept d 
where d.loc = 'CHICAGO' and e.deptno=d.deptno;


-- 2
select b.empno, b.ename, b.job, b.deptno  from emp a right outer join emp b on a.mgr = b.empno where a.ename is Null;


-- 3.
select ename, job, mgr 
from emp 
where mgr = (select mgr from emp where ename = 'blake');

-- 4.
select ename, hiredate 
from emp 
order by hiredate limit 5;

-- 5.
select ename, job, dname 
from emp, dept 
where mgr = (select empno from emp where ename = 'jones')
and emp.deptno = dept.deptno;