package com.ssafy.algo;
import java.util.Scanner;
import java.util.Stack;
public class Solution2493_김용희 {
		static class Tower{
			int num;
			int height;
		}
		public static void main(String[] args) {
			//1. 숫자를 만나면 기억한다.
			//2. 기억시키기전에 검사를 할건데,
			//	최근 기억들부터 되짚어보면서
			//	현재숫자보다 작은 기억은 삭제.
			
			//3. 삭제해나가다보니 기억이 다 사라진다면,
			//	나한테 레이저쏘는곳이 없음.
			//	자신보다 큰 것을 찾는 순간 그 다음기억으로 내가 들어감
			
			// #숫자만남.
			// 메모리가 있다면
			// 	최근 기억부터 따라가면서, 자신보다 큰것 찾기 .
			//	나보다 큰곳이 레이저를 쏜곳 
			//	기억의 마지막에 날 추가.
			
			Scanner sc = new Scanner(System.in);
			int N = sc.nextInt();
			
			//서서히 결과를 더해감
			StringBuilder sb = new StringBuilder();
			//지금껏 만났던 타워들에 대한 기억정보
			Stack<Tower> memory = new Stack<>();
			int idx=1;
			for(int i=0; i<N; i++) {
				int num = sc.nextInt();
				
				//기억이 없는건 나한테 레이저를 쏠것이 없음  
				if(memory.empty())
					sb.append(0).append(" ");
				else {
					//뒤에서부터 앞으로 나가며, 이번에 입력받은 타워보다 작으면 삭제.
					// 
					//	자신보다 크거나 스택비어질때까지 반복 .
					
					while(true) {
						if(memory.empty()) {
							sb.append(0).append(" ");
							break;
						}
						else if(memory.peek().height < num) {
							memory.pop();
						}
						else {
							sb.append(memory.peek().num).append(" ");
							break;
						}
					}// while끝
				}//else 끝 
				Tower t= new Tower();
				t.num = idx++;
				t.height = num;
				memory.push(t);
			}
			System.out.println(sb.toString());
			//기억을 저장할 공간을 준비해야하는데,
			// 기억에 기록되어야하는 내용! 순서와 크기 
			
		}//메인의끝 
	}
