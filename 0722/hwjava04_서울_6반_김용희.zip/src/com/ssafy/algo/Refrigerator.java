package com.ssafy.algo;

public class Refrigerator extends Product {
	
	private String L;
	
	public Refrigerator(int pnum, String pname, int price, int pcount,String L) {
		super(pnum, pname, price, pcount);
		this.L = L;
	}
	public String toString(){
		return super.toString() + " "+ "용량 :"+L;
	}
}

