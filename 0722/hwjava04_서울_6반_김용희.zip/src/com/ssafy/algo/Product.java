package com.ssafy.algo;

public class Product {
	private int pnum;
	private String pname;
	private int price;
	private int pcount;

	public Product(int pnum, String pname, int price, int pcount) {
		super();
		this.pnum = pnum;
		this.pname = pname;
		this.price = price;
		this.pcount = pcount;
	}
	public String toString() {
		return "제품번호:"+pnum+","+"제품명:"+pname+","+"가격:"+price+"재고수량:"+pcount;
	}
}
