package com.ssafy.algo;


public class ProductTest {

	public static void main(String[] args) {
		
		Televison tv = new Televison(1234, "Samsung", 3500000, 340, 50, "Soft");
		Refrigerator re = new Refrigerator(5678, "LG", 4000000, 66, "600L");
		
		System.out.println(tv.toString());
		System.out.println(re.toString());
	}

}
