package com.ssafy.algo;

public class Televison extends Product {
	
	private int inch;
	private String type;
	
	public Televison(int pnum, String pname, int price, int pcount, int inch, String type) {
		super(pnum, pname, price, pcount);
		this.inch = inch;
		this.type = type;
	}

	public String toString() {
		return super.toString() + " "+ "인치 :"+inch+"타입 :"+type;
	}

}
