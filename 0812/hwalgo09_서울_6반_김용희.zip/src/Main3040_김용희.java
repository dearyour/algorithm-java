
import java.util.Scanner;

public class Main3040_김용희 {
	//중복을 허용하지 않는 조합으로 합이 100인 7명을 구함.
	//구할것: 합이 100이되는 7개의 수
	static int arr[] = new int[9];
	static int res[] = new int[7];
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<9;i++) {
			arr[i] = sc.nextInt();
		}
		comb(0,0);
	}
	
	static void comb(int cnt,int start) {
		if(cnt == 7) {		//일곱개를 다 뽑았을때 
			int sum = 0;   //난쟁이 합을 담을 임시변수 
			for(int i=0;i<7;i++)
				sum += res[i];	 //일곱개를 썸에
			if(sum == 100) {	// 100인경우에만 출력
				for(int i=0;i<7;i++)
					System.out.println(res[i]);
			}
			return;
		}
		
		for(int i=start;i<9;i++) {
			res[cnt] = arr[i];
			comb(cnt+1, i+1);
		}
	}
}