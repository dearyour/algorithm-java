package algo;

import java.util.Arrays;
import java.util.Scanner;

	public class Soultion1289_김용희 {
	    public static void main(String[] args) {
	    	Scanner sc= new Scanner(System.in);
	    	int T = sc.nextInt();
	    	for (int TC = 1; TC <= T; TC++) {
				int cnt = 0;
				String str = sc.nextLine();
				
	    		int[] arr = new int[str.length()];
	    		int[] news = new int[str.length()];
	    		
	    		for (int i = 0; i < arr.length; i++) {
					arr[i] = str.charAt(i) - '0';
//					System.out.println(Arrays.toString(arr));
					
				}
	    		
	    		for (int i = 0; i < news.length; i++) {
					if(arr[i] !=news[i]) {
						for(int j=i; j<news.length; j++){
							news[j]= arr[i];
						}
						cnt++;
					}
				}
	    		System.out.println("# "+ TC + " "+ cnt);
			}
	    }
	}
	
	
/*
2
0011
100
*/
	
//// 이거 IM 문제랑 똑같이 푼거같은데 왜 패스가 안될까요 ..ㅜㅠ 다음 보충때 문의드릴꼐요~