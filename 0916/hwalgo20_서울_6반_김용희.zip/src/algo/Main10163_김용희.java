package algo;

import java.util.Arrays;
import java.util.Scanner;

public class Main10163_김용희 {
	public static void main(String[] args) throws Exception {
		Scanner sc= new Scanner(System.in);
		
		int N= sc.nextInt();   //테케
		int[][] arr=new int[1001][1001];
//		for(int[] b:arr) System.out.println(Arrays.toString(b)); System.out.println();
		for (int n = 1; n <= N; n++) {  //색종이 n 의수 
			int x = sc.nextInt();
			int y = sc.nextInt();
			int width= sc.nextInt();
			int height=sc.nextInt();
			
			for(int i=x; i<x+width; i++ ) { //문제가 x부터 기준임  x부터 하자  (0,0) (1,0) 증가할때
				for (int j=y; j<y+height; j++ ) {
					arr[i][j] =n;
					
					
				}
			}
//			for(int[] b:arr) System.out.println(Arrays.toString(b)); System.out.println();
			
		}
		
		for(int n=1; n<=N; n++) {  //색종이 숫자 탐색 
			int cnt =0;
			for(int i=0; i<1001; i++) {
				for(int j=0; j<1001; j++) {
					if(arr[i][j]==n) cnt++;
				}
			}
			System.out.println(cnt);
		}
		
		
	}
}
