package com.ssafy.algo;

import java.util.Scanner;

public class Main1149 {
		static int[][] ans = new int[1001][4];
		static int[][] rgb = new int[1001][4];
		static int R = 1;
		static int G = 2;
		static int B = 3;
		
		
		public static int min(int a, int b) {
			if (a < b)
				return a;
			else
				return b;
		}
		public static int min(int a, int b, int c) {
			if (a < b) {
				if (a < c)
					return a;
				else 
					return c;
			}
			else {
				if (b < c)
					return b;
				else
					return c;
			}
		}
		
		
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			int N = sc.nextInt();
			for (int i = 1; i <= N; i++) {
				for (int j = R; j <= B; j++) {
					rgb[i][j] = sc.nextInt();
				}
			}

			for (int i = 1; i <= N; i++) {
				for (int j = R; j <= 3; j++) {
					ans[i][j] = Integer.MAX_VALUE;
				}
			}
			ans[1][R] = rgb[1][R];  
			ans[1][G] = rgb[1][G];  
			ans[1][B] = rgb[1][B];  
			for (int i = 2; i <= N; i++) {
				for (int j = R; j <= B; j++) {
					for (int k = R; k <= B; k++) {
						if (j != k) {
							ans[i][j] = min(ans[i][j], rgb[i][j] + ans[i-1][k]);
						}
					}
				}
			}
			System.out.println(min(ans[N][R], ans[N][G], ans[N][B]));
		}

	}
