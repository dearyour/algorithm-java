use world;
#1
select code , name
from country
where name = "Afghanistan";

#2 
select c.name, l.language , l.percentage
from country c join countrylanguage l
on c.code = l.CountryCode
and l.percentage=100.0;


#7
select language 
from countrylanguage
join country
on country.Code = countrylanguage.CountryCode
and name = "south korea"
and percentage >50;


#13 # san marino로 검색 
select countrycode, language
from  countrylanguage l
join country c
on c.code = l.countrycode 
and localname = "san marino";

#14
select code , max(population)
from country c
group by name
order by 1 ;

#16
select code, name, localname,population
from country c
where Population;
