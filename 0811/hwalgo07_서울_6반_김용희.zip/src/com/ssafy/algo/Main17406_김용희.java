package com.ssafy.algo;
import java.io.*;
import java.util.*;

class Rotation {
	int x;
	int y;
	int size;

	Rotation(int x, int y, int size) {
		this.x = x;
		this.y = y;
		this.size = size;
	}
}

public class Main17406_김용희 {
	public static int N;
	public static int M;
	public static int K;
	public static int graph[][];
	public static int temp_graph[][];
	public static int dx[] = { 0, 0, 1, -1 };
	public static int dy[] = { 1, -1, 0, 0 };
	public static int answer = 0;
	public static ArrayList<Rotation> list = new ArrayList<Rotation>();

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine();
		String temp[] = str.split(" ");
		N = Integer.parseInt(temp[0]); // N * M배열
		M = Integer.parseInt(temp[1]);
		K = Integer.parseInt(temp[2]);

		graph = new int[N][M];
		temp_graph = new int[N][M];

		for (int i = 0; i < N; i++) {
			str = br.readLine();
			temp = str.split(" ");
			for (int j = 0; j < M; j++) {
				graph[i][j] = Integer.parseInt(temp[j]);
				temp_graph[i][j] = graph[i][j];
			}
		}

		for (int i = 0; i < K; i++) {
			str = br.readLine();
			temp = str.split(" ");
			list.add(new Rotation(Integer.parseInt(temp[0]), Integer.parseInt(temp[1]), Integer.parseInt(temp[2])));
		}

		int turn[] = new int[K];
		for (int k = 0; k < K; k++) {
			turn[k] = k;
		}

		permutataion(turn, 0, K, K);
		System.out.println(min);

	}// main함수 종료

	public static void rotate(int x, int y, int size) {
	
		for (int s = 1; s <= size; s++) {
			int a = graph[x - s][y - s];
			int b = graph[x - s][y + s];
			int c = graph[x + s][y + s];
			int d = graph[x + s][y - s];
			
			for (int j = y + s; j >= y - s + 2; j--) { // 오른쪽으로!
				graph[x - s][j] = graph[x - s][j - 1];
			}
			for (int i = x + s; i >= x - s + 2; i--) { // 아래로!
				graph[i][y + s] = graph[i - 1][y + s];
			}
			for (int j = y - s; j <= y + s - 2; j++) { // 왼쪽으로!
				graph[x + s][j] = graph[x + s][j + 1];
			}
			for (int i = x - s; i <= x + s - 2; i++) { // 윗쪽으로!
				graph[i][y - s] = graph[i + 1][y - s];
			}
			graph[x - s][y - s + 1] = a;
			graph[x - s + 1][y + s] = b;
			graph[x + s][y + s - 1] = c;
			graph[x + s - 1][y - s] = d;

		}

	

	}

	static void permutataion(int arr[], int depth, int n, int r) {
		if (depth == r) {
			for (int i = 0; i < K; i++) {
				//System.out.print(arr[i]+" s");
				rotate(list.get(arr[i]).x - 1, list.get(arr[i]).y - 1, list.get(arr[i]).size);
			}//System.out.println();
			calc();
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < M; j++) {
				//	System.out.print(graph[i][j] + " ");
					graph[i][j]= temp_graph[i][j];
				}
				//System.out.println();
			}
			//System.out.println("---------s");

			return;
		}

		for (int i = depth; i < n; i++) {
			swap(arr, depth, i);
			permutataion(arr, depth + 1, n, r);
			swap(arr, depth, i);
		}

	}

	public static void swap(int arr[], int depth, int i) {
		int temp = arr[depth];
		arr[depth] = arr[i];
		arr[i] = temp;
	}

	public static int min = Integer.MAX_VALUE;

	public static void calc() {
		for (int i = 0; i < N; i++) {
			int sum = 0;
			for (int j = 0; j < M; j++) {
				sum += graph[i][j];
			}
			if (sum < min)
				min = sum;
		}
	}

}