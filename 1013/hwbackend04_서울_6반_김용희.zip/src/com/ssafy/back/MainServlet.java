package com.ssafy.back;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.back.dto.Product;
import com.ssafy.back.dto.User;

@WebServlet("/main")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		System.out.println("action=["+action+"]");
		switch(action) {
			case "login":
				login(request, response);
				break;
			case "logout":
				logout(request, response);
				break;
			case "regist":
				regist(request, response);
				break;
			case "endprod":
				endprod(request, response);
				break;
			case "list":
				list(request, response);
				break;
		}
	}
	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		String pass=request.getParameter("pass");
		System.out.println("id=["+id+"] pass=["+pass+"]");
		if("ssafy".equals(id) && "1234".equals(pass)) {
			User user = new User(id,pass,"김용희");
			HttpSession session=request.getSession();
			
			session.setAttribute("userinfo", user);
			response.sendRedirect(request.getContextPath()+"/index.jsp");
		}else{
			request.setAttribute("msg", "로그인 실패 다시 로그인 해주세요.");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
	}
	private void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		session.invalidate();
		response.sendRedirect(request.getContextPath()+"/index.jsp");
	}
	private void regist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int product_no= Integer.parseInt(request.getParameter("product_no"));
		String product_name= request.getParameter("product_name");
		int product_price= Integer.parseInt(request.getParameter("product_price"));
		String product_desc= request.getParameter("product_desc");
		Product prod = new Product(product_no, product_name, product_price, product_desc);
		
		Cookie c =new Cookie("endprod", Integer.toString(product_no));
		c.setMaxAge(30*60);
		response.addCookie(c);
		
		int Nproudct_no=0;
		Nproudct_no=Integer.parseInt(c.getValue());
		
		request.setAttribute("result", "상품이 등록되었습니다.");
		request.setAttribute("prod", prod);
		request.getRequestDispatcher("/regist_result.jsp").forward(request,response);
	}
	private void endprod(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	Cookie[] ca = request.getCookies();
	if(ca!=null) {
		for(Cookie c : ca ) {
			if("endprod".equals(c.getName())) {
				int num = Integer.parseInt(c.getValue());
				Product prod = new Product(num, "Smart TV", 50000, "Smart...");// DB에서 가져올부분
				
				request.setAttribute("result", "마지막 등록한 상품.");
				request.setAttribute("prod", prod);
				request.getRequestDispatcher("/regist_result.jsp").forward(request,response);
				return;
			}
		}
	}
	request.setAttribute("msg","마지막 등록한 상품이 없습니다");
	request.getRequestDispatcher("/index.jsp").forward(request,response);
	}
	
	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		User user=(User) session.getAttribute("userinfo");
		if(user!=null) {
		List<Product> prods=new ArrayList<Product>();
        prods.add(new Product(1009,"Smart TV",50000,"Smart..."));
        prods.add(new Product(1010,"Computer",20000,"Computer..."));
        prods.add(new Product(1011,"NoteBook",25000,"NoteBook..."));
        prods.add(new Product(1012,"Tablet",  15000,"Tablet..."));
        prods.add(new Product(1013,"Phone",   10000,"Phone..."));  //DB에서 가져올 부분
        
        request.setAttribute("prods", prods);
        request.getRequestDispatcher("/list.jsp").forward(request, response);
		}else {
			request.setAttribute("msg", "로그인 후 이용 가능한 페이지 입니다.");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
	}
}
