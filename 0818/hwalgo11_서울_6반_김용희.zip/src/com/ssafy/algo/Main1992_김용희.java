package com.ssafy.algo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main1992_김용희 {
		static int[][] map;
		static String answer; // 출력할 문자열 저장하는 변수
		public static void main(String[] args) throws NumberFormatException, IOException {
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			int n=Integer.parseInt(br.readLine());
			map=new int[n][n];
			answer="";
			
			// 맵 생성
			for(int i=0;i<n;i++) {
				String[] input=br.readLine().split("");
				for(int j=0;j<n;j++) {
					if(input[j].equals("1")) map[i][j]=1; 
				}		//1일경우만 map에 1 칠하자 
			}
			
			// 큰 정사각형부터 점점 범위를 좁혀나가며 체크
			divide(0,0,n);
			System.out.println(answer);
		}
		
		// map[row][col]을 시작으로 사이즈 n 정사각형 범위안에 같은 수로만 구성되어 있는지 체크
		public static boolean isAble(int row, int col, int n) {
			int value=map[row][col];  //첫번쨰 시작값 저장 , 같은값일때만 압축 다른값나옴 false로 짜른다 
			for(int i=row;i<row+n;i++) {
				for(int j=col;j<col+n;j++) { //저장된 값이랑 다르면 한변의 크기를 반으로된 네개 사각형으로 재귀태우자
					if(map[i][j]!=value) return false;
				}
			}
			
			return true;
		}
	    
		public static void divide(int row, int col, int n) {
			if(isAble(row, col, n)) { 	// 같은 저장값 이라면 해당 위치 answer에 저장
				answer+=map[row][col];	
			}
			else { // 같은값 아니라면(펄스)  재귀태우자 
				answer+="(";
				int newSize=n/2;
				// 범위를 좁히고, 시작점을 지정하여 재귀호출
				divide(row, col, newSize);			      		//2 현재 위치
				divide(row, col+newSize, newSize);				//1 오른쪽 범위를 체크
				divide(row+newSize, col, newSize);				//3 현재위치 아래를 체크
				divide(row+newSize, col+newSize, newSize);		//4 현재위치 아래 오른쪽을 체크
				answer+=")";
			}
		}
		
	}
/*
8
11110000
11110000
00011100
00011100
11110000
11110000
11110011
11110011
*/